# Requires VS Code CLI 'code' in PATH.
$Root = (Resolve-Path "$PSScriptRoot\..\").Path
$ProfileName = "Data / DB & Analytics"
$Slug = "data-db-analytics"

if (-not (Get-Command code -ErrorAction SilentlyContinue)) {
  Write-Error "VS Code CLI 'code' not found"
  exit 1
}

$ExtList = Join-Path $Root 'workspace/.vscode/extensions.list'
if (-not (Test-Path $ExtList)) {
  Write-Error "extensions.list missing at $ExtList"
  exit 1
}

Write-Host "[$Slug] Ensuring profile '$ProfileName' exists"
code --profile "$ProfileName" --list-extensions *> $null

Write-Host "[$Slug] Installing extensions"
if ((Get-Content $ExtList | Where-Object {$_ -ne ''}).Count -gt 0) {
  Get-Content $ExtList | Where-Object {$_ -ne ''} | ForEach-Object {
    code --install-extension $_ --profile "$ProfileName"
  }
} else {
  Write-Warning "No extensions listed; skipping install"
}

$WsFile = Join-Path $Root "workspace/data-db-analytics.code-workspace"
if (Test-Path $WsFile) {
  Write-Host "[$Slug] Opening workspace"
  code $WsFile --profile "$ProfileName" --reuse-window *> $null
}

Write-Host "Done."
