# macOS – Apple Platforms & Tooling bundle (macos-apple-platforms)

This bundle is generated from agentic-dev-stacks. It contains a ready-to-use VS Code workspace and profile assets for **macOS – Apple Platforms & Tooling**.

## Quickstart (macOS/Linux)
```bash
./scripts/install-macos.sh   # or install-linux.sh
```

## Quickstart (Windows PowerShell)
```powershell
./scripts/Install-Windows.ps1
```

## What's inside
- workspace/ – .code-workspace and .vscode (settings, extensions.list, optional launch/tasks)
- mcp/ – servers manifest and generated codex-mcp TOML (copy snippets into ~/.codex/config.toml manually)
- prompts/ – suggested prompt packs for this stack
- scripts/ – profile-specific installers using VS Code CLI only
- pack-scripts/ – pack-level installers for all profiles in pack `00-core-base` (cross-platform)
- meta/bundle.meta.json – slug, pack, profile name

## Alternative: Pack-level installation
If you want to install all profiles from pack `00-core-base`:
```bash
# Linux
./pack-scripts/linux/install-profiles.sh

# macOS
./pack-scripts/macos/install-profiles.sh

# Windows PowerShell
./pack-scripts/windows/Install-Profiles.ps1
```

Or install specific profiles from the pack:
```bash
./pack-scripts/macos/install-profiles.sh macos-apple-platforms
```

## Regenerate
```bash
cd vscode
python scripts/build-bundles.py macos-apple-platforms
```

> Safety: installers use `code --profile` and never touch global settings or dotfiles directly. Copy MCP TOML blocks by hand.
