#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE_NAME="Python Services & CLIs"
SLUG="python-services-clis"

command -v code >/dev/null 2>&1 || { echo "VS Code CLI 'code' not found" >&2; exit 1; }

EXT_LIST="$ROOT/workspace/.vscode/extensions.list"
if [[ ! -f "$EXT_LIST" ]]; then
  echo "extensions.list missing at $EXT_LIST" >&2
  exit 1
fi

echo "[${SLUG}] Ensuring profile '${PROFILE_NAME}' exists"
code --profile "${PROFILE_NAME}" --list-extensions >/dev/null 2>&1 || true

echo "[${SLUG}] Installing extensions"
if [[ -s "$EXT_LIST" ]]; then
  xargs -n1 code --install-extension --profile "${PROFILE_NAME}" < "$EXT_LIST"
else
  echo "No extensions listed; skipping install" >&2
fi

WS_FILE="$ROOT/workspace/python-services-clis.code-workspace"
if [[ -f "$WS_FILE" ]]; then
  echo "[${SLUG}] Opening workspace"
  code "$WS_FILE" --profile "${PROFILE_NAME}" --reuse-window >/dev/null 2>&1 || true
fi

echo "Done."
