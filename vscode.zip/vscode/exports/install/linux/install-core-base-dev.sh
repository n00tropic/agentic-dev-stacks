#!/usr/bin/env bash
# Installer for the core-base-dev export (Linux / bash).
# Usage:
#   ./install-core-base-dev.sh            # installs extensions, opens workspace
#   NO_OPEN=1 ./install-core-base-dev.sh  # install only
#
# Behaviour:
# - Reads extension IDs from ../workspaces/core-base-dev/.vscode/extensions.list
# - Installs via VS Code CLI: code --install-extension <id>
# - Opens workspace unless NO_OPEN=1
# - Uses only relative paths; no machine-specific values.

set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
workspace_dir="$(cd "${script_dir}/../workspaces/core-base-dev" && pwd)"
extensions_file="${workspace_dir}/.vscode/extensions.list"
workspace_file="${workspace_dir}/core-base-dev.code-workspace"
profile_name="Core / Base Dev"

if ! command -v code >/dev/null 2>&1; then
	echo "error: VS Code CLI 'code' not found in PATH" >&2
	exit 1
fi

if [[ ! -f ${extensions_file} ]]; then
	echo "error: extensions list missing at ${extensions_file}" >&2
	exit 1
fi

while IFS= read -r ext; do
	[[ -z ${ext} || ${ext} == \#* ]] && continue
	echo "Installing ${ext} ..."
	code --install-extension "${ext}"
done <"${extensions_file}"

echo "Extensions installed."

if [[ ${NO_OPEN:-0} != "1" ]]; then
	echo "Opening workspace..."
	code "${workspace_file}" --profile "${profile_name}"
else
	echo "NO_OPEN=1 set; skipping workspace open."
fi

echo "Done."
