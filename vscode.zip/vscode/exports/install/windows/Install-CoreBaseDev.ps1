<#
Installer for the core-base-dev export (Windows PowerShell).

Usage:
  .\Install-CoreBaseDev.ps1            # installs extensions, opens workspace
  .\Install-CoreBaseDev.ps1 -NoOpen    # install only

Behaviour:
- Reads extension IDs from ..\workspaces\core-base-dev\.vscode\extensions.list
- Installs via VS Code CLI: code --install-extension <id>
- Opens workspace unless -NoOpen is supplied
- Uses relative paths only; no machine-specific values.
#>
param(
  [switch]$NoOpen
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$WorkspaceDir = Resolve-Path (Join-Path $ScriptDir "..\workspaces\core-base-dev")
$ExtensionsFile = Join-Path $WorkspaceDir ".vscode\extensions.list"
$WorkspaceFile = Join-Path $WorkspaceDir "core-base-dev.code-workspace"
$ProfileName = "Core / Base Dev"

if (-not (Get-Command code -ErrorAction SilentlyContinue)) {
  Write-Error "VS Code CLI 'code' not found in PATH"
  exit 1
}

if (-not (Test-Path $ExtensionsFile)) {
  Write-Error "Extensions list missing at $ExtensionsFile"
  exit 1
}

Get-Content $ExtensionsFile | ForEach-Object {
  $ext = $_.Trim()
  if ([string]::IsNullOrWhiteSpace($ext) -or $ext.StartsWith('#')) { return }
  Write-Host "Installing $ext ..."
  & code --install-extension $ext
}

Write-Host "Extensions installed."

if (-not $NoOpen) {
  Write-Host "Opening workspace..."
  & code $WorkspaceFile --profile $ProfileName
} else {
  Write-Host "-NoOpen supplied; skipping workspace open."
}

Write-Host "Done."
