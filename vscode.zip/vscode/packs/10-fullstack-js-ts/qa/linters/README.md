# Linters and formatters

Configuration for linters, formatters, and test runners.
