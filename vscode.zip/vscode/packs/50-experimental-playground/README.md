# 50-experimental-playground

Heavy or experimental tools, preview extensions, and sandbox profiles that should not slow down your main packs.

## Intent

- Canonical, reusable VS Code configuration for this domain.
- Always includes GitHub Copilot, Codex, and core QA tooling by default; experimental add-ons stay opt-in.
- Designed to be OS-agnostic: works on macOS, Windows, and Linux.
