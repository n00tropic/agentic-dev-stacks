# Profiles

Profile descriptors (`PROFILE.<slug>.md`) and exported VS Code profile files.
