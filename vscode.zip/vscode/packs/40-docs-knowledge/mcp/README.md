# MCP configuration

MCP client/server configuration for this pack.
