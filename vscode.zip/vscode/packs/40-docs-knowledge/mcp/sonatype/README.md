# Sonatype MCP

Configuration for dependency-intelligence MCP services.
