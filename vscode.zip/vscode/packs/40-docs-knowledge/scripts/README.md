# Scripts

Helper scripts for applying this pack on each OS.
