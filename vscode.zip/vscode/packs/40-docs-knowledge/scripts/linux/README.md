# Linux scripts

Bootstrap scripts for applying this pack on Linux.
