# Windows scripts

Bootstrap scripts for applying this pack on Windows.
