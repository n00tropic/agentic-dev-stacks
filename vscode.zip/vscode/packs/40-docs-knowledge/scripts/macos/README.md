# macOS scripts

Bootstrap scripts for applying this pack on macOS.
