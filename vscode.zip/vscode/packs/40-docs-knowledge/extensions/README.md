# Extensions

Curated extension lists for each profile. Install via `code --install-extension`.
