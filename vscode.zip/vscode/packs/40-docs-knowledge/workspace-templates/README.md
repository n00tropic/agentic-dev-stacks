# Workspace templates

Example `.code-workspace` files for this pack.
