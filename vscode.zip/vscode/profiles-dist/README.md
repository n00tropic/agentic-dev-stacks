# Profile Exports

Export VS Code profiles via **Export Profile…** and save them here. Do not hand-edit `.code-profile` files.

For the agent ecosystems stack, export the JS/TS profile to `fullstack-js-ts.code-profile`.
